"""DemoTutorial URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from DemoTutorial.core import views as core_views
from django.contrib.auth import views as auth_views
from django.views.generic import TemplateView

urlpatterns = [
    path('admin/', admin.site.urls),
    url(r'^$', core_views.home, name='home'),
    url(r'^login/$', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    url(r'^logout/$', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
    # url(r'^password_reset/$', auth_views.PasswordResetView.as_view(), name='password_reset'),
    url(r'^account_activation_sent/$', core_views.account_activation_sent, name='account_activation_sent'),
    url(r'^activate/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$', core_views.activate, name='activate'),
    url(r'^hello/$', core_views.hello, name = 'hello'),
    url(r'^morning/$', core_views.morning, name = 'morning'),
    url(r'^article/(\d+)/$', core_views.viewArticle, name = 'article'),
    url(r'^articles/(\d{2})/(\d{4})/$', core_views.viewArticles, name = 'articles'),
    url(r'^index1/$', core_views.index1, name = 'index1'),
    url(r'^index/$', TemplateView.as_view(template_name="index.html"), name = 'index'),
    url(r'^f_a/$', TemplateView.as_view(template_name="f_a.html"), name = 'f_a'),
    url(r'^f_b/$', TemplateView.as_view(template_name="f_b.html"), name = 'f_b'),
    url(r'^f_b/$', TemplateView.as_view(template_name="f_b.html"), name = 'f_b'),
    url(r'^a/$', TemplateView.as_view(template_name="a.html"), name = 'a'),
    url(r'^b/$', TemplateView.as_view(template_name="b.html"), name = 'b'),
    url(r'^ItoView/$', TemplateView.as_view(template_name="ItoView.html"), name = 'ItoView'),
    url(r'^CPU_ALL/$', TemplateView.as_view(template_name="CPU_ALL.html"), name = 'CPU_ALL'),
    url(r'^DISK/$', TemplateView.as_view(template_name="DISK.html"), name = 'DISK'),
    url(r'^MEM/$', TemplateView.as_view(template_name="MEM.html"), name = 'MEM'),
    url(r'^MEM_FIA/$', TemplateView.as_view(template_name="MEM_FIA.html"), name = 'MEM_FIA'),
    url(r'^VM/$', TemplateView.as_view(template_name="VM.html"), name = 'VM'),
    url(r'^IO/$', TemplateView.as_view(template_name="IO.html"), name = 'IO'),
    url(r'^TOP/$', TemplateView.as_view(template_name="TOP.html"), name = 'TOP'),
    url(r'^PROC/$', TemplateView.as_view(template_name="PROC.html"), name = 'PROC'),
    url(r'^NET/$', TemplateView.as_view(template_name="NET.html"), name = 'NET'),
    url(r'^BouView/$', TemplateView.as_view(template_name="BouView.html"), name = 'BouView'),
    url(r'^ItmView/$', TemplateView.as_view(template_name="ItmView.html"), name = 'ItmView'),
    url(r'^submit/$', TemplateView.as_view(template_name="submit.html"), name = 'submit'),
    url(r'^test1/$', TemplateView.as_view(template_name="test1.html"), name = 'test1'),
    url(r'^test2/$', TemplateView.as_view(template_name="test2.html"), name = 'test2'),
    url(r'^MEM_FIA/$', TemplateView.as_view(template_name="MEM_FIA.html"), name = 'MEM_FIA'),
    # url(r'^index/$', core_views.index, name = 'index'),
    # url(r'^a/$', core_views.a, name = 'a'),
    # url(r'^b/$', core_views.b, name = 'b'),
    # url(r'^f_a/$', core_views.f_a, name = 'f_a'),
    # url(r'^f_b/$', core_views.f_b, name = 'f_b'),
    # url(r'^ItoView/$', core_views.ItoView, name = 'ItoView'),
    # url(r'^submit/$', core_views.submit, name = 'submit'),
    # url(r'^test1/$', core_views.test1, name = 'test1'),
    # url(r'^test2/$', core_views.test2, name = 'test2'),
    # url(r'^MEM_FIA/$', core_views.MEM_FIA, name = 'MEM_FIA'),
]
