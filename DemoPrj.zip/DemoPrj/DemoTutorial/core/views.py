# from django.contrib.auth import login, authenticate
# from django.contrib.auth.forms import UserCreationForm
# from django.shortcuts import render, redirect
#
# def signup(request):
#     if request.method == 'POST':
#         form = UserCreationForm(request.POST)
#         if form.is_valid():
#             form.save()
#             username = form.cleaned_data.get('username')
#             raw_password = form.cleaned_data.get('password1')
#             user = authenticate(username=username, password=raw_password)
#             login(request, user)
#             return redirect('home')
#     else:
#         form = UserCreationForm()
#     return render(request, 'signup.html', {'form': form})

from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.sites.shortcuts import get_current_site
from django.shortcuts import render, redirect
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from django.http import HttpResponse
# from DemoTutorial.core.forms import SignUpForm
from DemoTutorial.core.tokens import account_activation_token

@login_required
def home(request):
    return render(request, 'home.html')

@login_required
def morning(request):
    return render(request, 'morning.html')

@login_required
def hello(request):
    return render(request, 'hello.html')

@login_required
def viewArticle(request, articleId):
    text = "Displaying article Number : %s"%articleId
    return HttpResponse(text)

@login_required
def viewArticles(request, month, year):
    text = "Displaying articles of : %s/%s"%(year, month)
    return HttpResponse(text)

@login_required
def index1(request):
    return render(request, 'index1.html')

@login_required
def index(request):
    return render(request, 'index.html')

@login_required
def a(request):
    return render(request, 'a.html')

@login_required
def b(request):
    return render(request, 'b.html')

@login_required
def f_a(request):
    return render(request, 'f_a.html')

@login_required
def f_b(request):
    return render(request, 'f_b.html')

@login_required
def ItoView(request):
    return render(request, 'ItoView.html')

@login_required
def test1(request):
    return render(request, 'test1.html')

@login_required
def test2(request):
    return render(request, 'test2.html')

@login_required
def submit(request):
    return render(request, 'submit.html')

@login_required
def MEM_FIA(request):
    return render(request, 'MEM_FIA.html')

# def viewArticles(request, month, year):
#     if request.user.is_authenticated:
#         text = "Displaying articles of : %s/%s"%(year, month)
#     else:
#         text = "Please Login first to access this page"
#     return HttpResponse(text)

# def signup(request):
#     if request.method == 'POST':
#         form = SignUpForm(request.POST)
#         if form.is_valid():
#             user = form.save(commit=False)
#             user.is_active = False
#             user.save()
#
#             current_site = get_current_site(request)
#             subject = 'Activate Your MySite Account'
#             message = render_to_string('account_activation_email.html', {
#                 'user': user,
#                 'domain': current_site.domain,
#                 'uid': urlsafe_base64_encode(force_bytes(user.pk)),
#                 'token': account_activation_token.make_token(user),
#             })
#             user.email_user(subject, message)
#
#             return redirect('account_activation_sent')
#     else:
#         form = SignUpForm()
#     return render(request, 'signup.html', {'form': form})


def account_activation_sent(request):
    return render(request, 'account_activation_sent.html')

def activate(request, uidb64, token):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.profile.email_confirmed = True
        user.save()
        login(request, user)
        return redirect('home')
    else:
        return render(request, 'account_activation_invalid.html')
